# vim-CopyCode
Self-use for copy some code using keywords in program competition
# Install
  * `cd` to your `$HOME/.vim/pack/anyname/start`
  * `git clone https://github.com/paradoxskin/vim-CopyCode.git`
  * done
  
# Usage
* add the code file in codes file
* edit the .config file as example:`<filename:key1,key2,key3...>`,and one line one file
* map `:Coco ` in your vimrc or not
* `:Coco <key>` to add code in your current file
