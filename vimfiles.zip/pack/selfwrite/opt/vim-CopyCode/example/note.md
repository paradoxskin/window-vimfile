copy `codes/` ,create`.config` in `..`

in your `.config`,write

```
segmentree:seg,segment,segmentreesad
```
