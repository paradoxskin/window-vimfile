## Actual behavior (Required!)


## Expected behavior (Required!)


## The steps to reproduce actual behavior (Required!)
 1. ...
 2. ...
 3. ...


## Environment (Required!)
 * OS:
 * Vim version:
 * Neovim version:


## Q&A
* Yes, I tried minimal .vimrc configuraion.
* Yes, I have enabled logs with `JCdebugEnableLogs` and can put here content of `JCdebugGetLogContent` command, if you need.
* Even, if you wish, I can set `g:JavaComplete_JavaviLogLevel` to `'debug'`, then set `g:JavaComplete_JavaviLogDirectory`, and put here server logs, too.


## Screenshot (Optional)


## The output of :redir and :message (Optional)
