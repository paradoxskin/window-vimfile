package kg.ash.javavi.searchers;

import java.util.List;

public interface PackageSeacherIFace {
    List<PackageEntry> loadEntries();
}
