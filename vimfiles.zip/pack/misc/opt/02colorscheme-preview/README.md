# How to use
`:ColorschemePreview`
(Command name might be changed...)

# Vim version
Validated with v8.1.1566

# TODO
Support older Vim version (no popup window)

# Screenshot
![screenshot](https://github.com/mnishz/colorscheme-preview.vim/blob/master/images/colorscheme_preview.gif)
