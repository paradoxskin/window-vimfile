#! /bin/sh
~/github/vim-tools/html2vimdoc/bin/python ~/github/vim-tools/html2vimdoc.py -f apc -t vim-auto-popmenu ../README.md > apc.txt

