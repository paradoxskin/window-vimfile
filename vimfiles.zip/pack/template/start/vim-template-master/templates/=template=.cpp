#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define endl '\n'
#define push_back emplace_back
#define pii pair<int,int>
#define ull unsigned long long
/*
 * theFileCreatedAt_%DATE%_%TIME%_ *
 * 只有结束的时候才会结束
 */
ll read(){
	ll w=1,q=0;
	char ch=' ';
	while(ch!='-'&&(ch<'0'||ch>'9')) ch=getchar();
	if(ch=='-') w=-1,ch=getchar();
	while(ch>='0'&&ch<='9') q=(ll)q*10+ch-'0',ch=getchar();
	return (ll)w*q;
}
void solve(){
	%HERE%
}
int main(){
	#ifndef LOCAL
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	#endif
	int t;
	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
