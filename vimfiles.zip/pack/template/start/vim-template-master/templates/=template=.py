import io,os
input=io.BytesIO(os.read(0,os.fstat(0).st_size)).readline

def main(t):
	%HERE%

T=int(input())
t=1
while t<=T:
	main(t)
	t+=1
