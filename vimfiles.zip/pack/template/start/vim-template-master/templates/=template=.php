<?php
/**
 * Short description for %FFILE%
 *
 * @package %FILE%
 * @author %USER% <%MAIL%>
 * @version 0.1
 * @copyright (C) %YEAR% %USER% <%MAIL%>
 * @license %LICENSE%
 */

%HERE%
