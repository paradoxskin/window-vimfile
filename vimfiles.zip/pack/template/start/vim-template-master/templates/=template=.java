/*
 * %FFILE%
 * Copyright (C) %YEAR% %USER% <%MAIL%>
 *
 * Distributed under terms of the %LICENSE% license.
 */

public class %FILE%{
	public static void main(String[] args){
		%HERE%
	}
}

